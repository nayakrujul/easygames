from easygames.easygames import rock_paper_scissors, guess_the_number, fizz_buzz
