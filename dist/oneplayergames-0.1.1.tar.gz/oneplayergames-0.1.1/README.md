# easygames
The easygames library in Python
